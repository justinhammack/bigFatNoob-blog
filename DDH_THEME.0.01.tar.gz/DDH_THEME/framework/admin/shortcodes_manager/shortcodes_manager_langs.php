<?php
$strings = "tinyMCE.addI18n({en:{
shortcodes_manager:{
desc : 'Shortcodes Manager'
}}});
";

?>