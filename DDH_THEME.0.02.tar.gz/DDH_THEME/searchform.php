<div class="search-widget">
	<form action="<?php bloginfo('url'); ?>/" id="search" method="get">
		<fieldset>
			<input type="text" id="s" name="s" value="" />
			<input type="submit" title="Search" value="" id="submit-search" />
		</fieldset>
	</form>
</div>