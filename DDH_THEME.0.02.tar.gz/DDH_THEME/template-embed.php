<?php
/**
 * Template Name: Vanilla Forum Template
 *
 * A custom page template for a Vanilla Forum.
 *
 * The "Template Name:" bit above allows this to be selectable
 * from a dropdown menu on the edit page screen.
 *
 */

get_header(); ?>

<script type="text/javascript" src="http://ddh.bigfatnoob.com/plugins/embedvanilla/remote.js"></script>

<?php get_footer();