Created by Adam Glaysher (adamglaysher@gmail.com)
-------------------------------------------------

How to install:
1. Move the whole 'DarkMist' folder into your themes directory (.../themes).
2. Access the dashboard and click on 'Themes'.
3. Find the theme named 'Dark Mist' and select Apply.

-------------------------------------------------