<?php get_header(); ?>
<?php include_once(THEME.'/category.php'); ?>
<?php get_footer(); ?>